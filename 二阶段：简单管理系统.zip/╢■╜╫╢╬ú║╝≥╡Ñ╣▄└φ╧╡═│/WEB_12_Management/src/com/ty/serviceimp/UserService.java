package com.ty.serviceimp;
import java.util.List;
import com.ty.dao.IUserDao;
import com.ty.daoimp.UserDao;
import com.ty.pojo.Notice;
import com.ty.pojo.User;
import com.ty.service.IUserService;
import com.ty.utils.ObjectUtils;
/**
 * �û������ʵ����
* @ClassName: UserService  
* @Description: TODO(������һ�仰��������������)  
* @author Administrator  
* @date 2018��1��1��  
*
 */
public class UserService implements IUserService{
	private UserDao userDao = null;
	/**
	 * ��ȡuserDao�Ķ���
	* @throws Exception
	 */
    public UserService() throws Exception {
    	userDao = (UserDao) ObjectUtils.getObject("userDao");
    }
	@Override
	public void insert(User user) throws Exception {
		if (user==null||user.getuName().equals("")||user.getuLoginName().equals("")) {
			throw new RuntimeException("���ȡ�Ķ���������");
		}else {
			userDao.insert(user);
		}
	}

	@Override
	public void deleteUserById(User user) throws Exception {
		if (user==null||user.getuId()==null) {
			throw new RuntimeException("���ȡ�Ķ���������");
		}else {
			userDao.deleteUserById(user);
		}
	}
	
	@Override
	public User findUserByUserNameAndPwd(User user) throws Exception {
		if (user.getuLoginName().equals("")||user.getuPwd().equals("")) {
			throw new RuntimeException("û����д��½�Ĳ���");
		}
		User user2 = userDao.findUserByUserNameAndPwd(user);
		if (user2==null) {
			throw new RuntimeException("�û����������벻��ȷ");
		}
		return user2;
	}

	@Override
	public void updateUserById(User user) throws Exception {
		if (user==null||user.getuCreateTime().equals("")||user.getuLoginName().equals("")||user.getuName().equals("")||user.getuPwd().equals("")||user.getuState().equals("")) {
			throw new RuntimeException("���ȡ�Ķ���������");
		}else {
			userDao.updateUserById(user);
		}
	}

	@Override
	public List<User> findUserByUserNameAndStateLike(User user) throws Exception {
		return userDao.findUserByUserNameAndStateLike(user);
	}

	@Override
	public List<User> findAll() throws Exception {
		return userDao.findAll();
	}
	@Override
	public User queryOneUser(User user) throws Exception {
		if (user.getuId()==null) {
			throw new RuntimeException("������û�������");
		}
		return userDao.queryOneUser(user);
	}
	@Override
	public String findNameById(Integer uId) throws Exception {
		return userDao.findNameById(uId);
	}
	@Override
	public List<Notice> findNoticesByUserId(User user) throws Exception {
		return userDao.findNoticesByUserId(user);
	}
}
