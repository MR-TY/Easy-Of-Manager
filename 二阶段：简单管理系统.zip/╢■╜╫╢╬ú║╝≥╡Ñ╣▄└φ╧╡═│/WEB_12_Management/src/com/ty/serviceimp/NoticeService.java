package com.ty.serviceimp;
import java.util.List;

import com.ty.daoimp.NoticeDao;
import com.ty.pojo.Notice;
import com.ty.service.INoticeService;
import com.ty.utils.ObjectUtils;
/**
 * ��������ʵ����
* @ClassName: NoticeService  
* @Description: TODO(������һ�仰��������������)  
* @author Administrator  
* @date 2018��1��1��  
*
 */
public class NoticeService implements INoticeService{
	NoticeDao noticeDao = null;
	public NoticeService() throws Exception {
		noticeDao = (NoticeDao) ObjectUtils.getObject("noticeDao");
	}
	@Override
	public void insert(Notice notice) throws Exception {
		if (notice==null||notice.getnContent().equals("")||notice.getnCreateTime().equals("")||notice.getnName().equals("")||notice.getuId()==null) {
			throw new RuntimeException("������Ķ���������");
		}else {
			noticeDao.insert(notice);
		}
	}

	@Override
	public void deleteNoticeById(Notice notice) throws Exception {
		if (notice.getnId()==null) {
			throw new RuntimeException("������Ķ���������");
		}else {
			noticeDao.deleteNoticeById(notice);
		}
	}

	@Override
	public void updateNoticeById(Notice notice) throws Exception {
		if (notice.getnContent().equals("")||notice.getnCreateTime().equals("")||notice.getnName().equals("")) {
			throw new RuntimeException("������Ķ���������");
		}else {
			noticeDao.updateNoticeById(notice);
		}
	}

	@Override
	public  List<Notice> findAllNotice() throws Exception {
		return noticeDao.findAllNotice();
	}

	@Override
	public Notice findNoticeById(Notice notice) throws Exception {
		if (notice.getnId()==null) {
			throw new RuntimeException("������Ķ���������");
		}else {
			notice = noticeDao.findNoticeById(notice);
		}
		return notice;
	}

	@Override
	public List<Notice> findNoticeByNameAndContentLike(Notice notice) throws Exception {
		return noticeDao.findNoticeByNameAndContentLike(notice);
	}
	@Override
	public void updateNoticeUId(Notice notice) throws Exception {
		noticeDao.updateNoticeUId(notice);
	}

}
