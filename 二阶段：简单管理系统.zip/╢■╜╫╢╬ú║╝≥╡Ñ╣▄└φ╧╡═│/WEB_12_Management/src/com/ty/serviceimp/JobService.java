package com.ty.serviceimp;
import java.util.List;
import com.ty.daoimp.JobDao;
import com.ty.pojo.Employee;
import com.ty.pojo.Job;
import com.ty.service.IJobService;
import com.ty.utils.ObjectUtils;
/**
 * ְλ�����ʵ����
* @ClassName: JobService  
* @Description: TODO(������һ�仰��������������)  
* @author Administrator  
* @date 2018��1��1��  
*
 */
public class JobService implements IJobService{
	JobDao jobDao = null; 
	public JobService() throws Exception {
		jobDao = (JobDao) ObjectUtils.getObject("jobDao");
	}
	@Override
	public void insert(Job job) throws Exception {
		if (job.getjDes().equals("")||job.getjName().equals("")) {
			throw new RuntimeException("������Ķ���������");
		}else {
			jobDao.insert(job);
		}
	}

	@Override
	public void deleteJobById(Job job) throws Exception {
		if (job.getjId()==null) {
			throw new RuntimeException("������Ķ���������");
		}else {
			jobDao.deleteJobById(job);
		}
	}

	@Override
	public void updateJobById(Job job) throws Exception {
		if (job.getjDes().equals("")||job.getjName().equals("")){
			throw new RuntimeException("������Ķ���������");
		} else {
			jobDao.updateJobById(job);
		}
	}

	@Override
	public List<Job> findJobByNameLike(Job job) throws Exception {
		return jobDao.findJobByNameLike(job);
	}

	@Override
	public List<Job> findJobAll() throws Exception {
		return jobDao.findJobAll();
	}
	@Override
	public Job findOneJob(Job job) throws Exception {
		return jobDao.findOneJob(job);
	}
	@Override
	public String findNameById(Integer jId) throws Exception {
		return jobDao.findNameById(jId);
	}
	@Override
	public List<Employee> findEmpByJobId(Job job) throws Exception {
		return jobDao.findEmpByJobId(job);
	}
	

}
