package com.ty.serviceimp;
import java.util.List;
import com.ty.dao.IDeptDao;
import com.ty.daoimp.DeptDao;
import com.ty.pojo.Dept;
import com.ty.pojo.Employee;
import com.ty.service.IDeptService;
import com.ty.utils.ObjectUtils;
/**
 * ���ŷ����ʵ����
* @ClassName: DeptService  
* @Description: TODO(������һ�仰��������������)  
* @author Administrator  
* @date 2018��1��1��  
*
 */
public class DeptService implements IDeptService{
	DeptDao deptDao = null;
	public DeptService() throws Exception {
		deptDao = (DeptDao) ObjectUtils.getObject("deptDao");
	}
 	@Override
	public void insert(Dept dept) throws Exception {
		if (dept.getdDes().equals("")||dept.getdName().equals("")) {
			throw new RuntimeException("������Ķ���������");
		}else {
			deptDao.insert(dept);
		}
	}

	@Override
	public void deleteDeptById(Dept dept) throws Exception {
		if (dept.getdId()==null) {
			throw new RuntimeException("������Ķ���������");
		}else {
			deptDao.deleteDeptById(dept);
		}
	}

	@Override
	public void updateDeptById(Dept dept) throws Exception {
		if (dept.getdDes().equals("")||dept.getdName().equals("")) {
			throw new RuntimeException("������Ķ���������");
		}else {
			deptDao.updateDeptById(dept);
		}
	}

	@Override
	public List<Dept> findDeptByDeptNameLike(Dept dept) throws Exception {

		return deptDao.findDeptByDeptNameLike(dept);
	}

	@Override
	public List<Dept> findDeptAll() throws Exception {

		return deptDao.findDeptAll();
	}
	@Override
	public Dept findOneDept(Dept dept) throws Exception {
		return deptDao.findOneDept(dept);
	}
	@Override
	public String findNameById(Integer dId) throws Exception {
		return deptDao.findNameById(dId);
	}
	@Override
	public List<Employee> findEmpByDeptId(Dept dept) throws Exception {
		return deptDao.findEmpByDeptId(dept);
	}
}
