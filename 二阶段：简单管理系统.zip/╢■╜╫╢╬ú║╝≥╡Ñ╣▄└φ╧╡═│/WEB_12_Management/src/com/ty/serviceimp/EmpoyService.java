package com.ty.serviceimp;
import java.util.List;
import com.ty.daoimp.EmpoyDao;
import com.ty.pojo.Employee;
import com.ty.service.IEmpoyService;
import com.ty.utils.ObjectUtils;
/**
 * Ա�������ʵ����
* @ClassName: EmpoyService  
* @Description: TODO(������һ�仰��������������)  
* @author Administrator  
* @date 2018��1��1��  
*
 */
public class EmpoyService implements IEmpoyService{
	EmpoyDao empoyDao = null;
	public EmpoyService() throws Exception {
		empoyDao = (EmpoyDao) ObjectUtils.getObject("empoyDao");
	}
	@Override
	public void insert(Employee employee) throws Exception {
		if (employee.getdId()==null||employee.geteAddress().equals("")||employee.geteCreateTime().equals("")
				||employee.geteEmail().equals("")||employee.geteGender()==null||employee.geteIdCard().equals("")
				||employee.geteName().equals("")||employee.geteStu().equals("")||employee.geteTelNum().equals("")
				||employee.getjId()==null) {
				throw new RuntimeException("�㴫��Ķ���������");
		}else {
			empoyDao.insert(employee);
		}
	}

	@Override
	public void deleteEmployById(Employee employee) throws Exception {
		if (employee.geteId()==null) {
			throw new RuntimeException("�㴫��Ķ���������");
		}else {
			empoyDao.deleteEmployById(employee);
		}
	}

	@Override
	public void updateEmployById(Employee employee) throws Exception {
		if (employee.getdId()==null||employee.geteAddress().equals("")||employee.geteCreateTime().equals("")
				||employee.geteEmail().equals("")||employee.geteGender()==null||employee.geteIdCard().equals("")
				||employee.geteName().equals("")||employee.geteStu().equals("")||employee.geteTelNum().equals("")
				||employee.getjId()==null) {
				throw new RuntimeException("�㴫��Ķ���������");
		}else {
			empoyDao.updateEmployById(employee);
		}
	}
	@Override
	public List<Employee> findEmployByCompositionCondition(Employee employee) throws Exception {

		return empoyDao.findEmployByCompositionCondition(employee);
	}

	@Override
	public List<Employee> findAll() throws Exception {
		return empoyDao.findAll();
	}
	@Override
	public Employee findOneEmp(Employee employee) throws Exception {
		return empoyDao.findOneEmp(employee);
	}
	@Override
	public void updateEmpId(Employee employee) throws Exception {
		empoyDao.updateEmpId(employee);
	}
	@Override
	public void updateEmpJId(Employee employee) throws Exception {
		empoyDao.updateEmpJId(employee);
	}

}
