package com.ty.serviceimp;
import java.util.List;
import com.ty.daoimp.DownLoadDao;
import com.ty.pojo.Download;
import com.ty.service.IDownLoadService;
import com.ty.utils.ObjectUtils;
/**
 * �������ķ����ʵ����
* @ClassName: DownLoadService  
* @Description: TODO(������һ�仰��������������)  
* @author Administrator  
* @date 2018��1��1��  
*
 */
public class DownLoadService implements IDownLoadService{
	DownLoadDao downLoadDao = null;
	public DownLoadService() throws Exception {
		downLoadDao = (DownLoadDao) ObjectUtils.getObject("downLoadDao");
	}
	@Override
	public void insert(Download download) throws Exception {
		if (download.getDoDes().equals("")||download.getDoTitle().equals("")||download.getDoCreateTime().equals("")||download.getDoCreateTime().equals("")||download.getuId()==null) {
			throw new RuntimeException("�㴫��Ķ���������");
		}else {
			downLoadDao.insert(download);
		}
	}

	@Override
	public void deleteDownloadById(Download download) throws Exception {
		if (download.getDoId()==null) {
			throw new RuntimeException("�㴫��Ķ���������");
		}else {
			downLoadDao.deleteDownloadById(download);
		}
	}

	@Override
	public void updateDownloadById(Download download) throws Exception {
		if (download.getDoDes().equals("")||download.getDoTitle().equals("")||download.getDoCreateTime().equals("")||download.getFilePath().equals("")||download.getDoCreateTime().equals("")||download.getuId()==null) {
			throw new RuntimeException("�㴫��Ķ���������");
		}else {
			downLoadDao.updateDownloadById(download);
		}
	}

	@Override
	public List<Download> findDownloadByTitileName(Download download) throws Exception {
		return downLoadDao.findDownloadByTitileName(download);
	}

	@Override
	public List<Download> findAllDownload() throws Exception {
		return downLoadDao.findAllDownload();
	}
	@Override
	public Download findOneFile(Download download) throws Exception {
		return downLoadDao.findOneFile(download);
	}
}
