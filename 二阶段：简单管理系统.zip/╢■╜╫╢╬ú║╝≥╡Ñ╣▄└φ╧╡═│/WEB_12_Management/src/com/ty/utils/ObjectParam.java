package com.ty.utils;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;

public class ObjectParam {
	public static <T>T getObject(HttpServletRequest request,Class<T> clazz) throws Exception, Exception{
		T t = clazz.newInstance();
		BeanUtils.populate(t, request.getParameterMap());
		return t;
	}
}
