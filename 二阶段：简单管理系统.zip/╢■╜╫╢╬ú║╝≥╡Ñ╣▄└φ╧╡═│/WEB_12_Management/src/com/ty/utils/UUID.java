package com.ty.utils;

public class UUID {
	public static String getUUID(){
		java.util.UUID uuid = java.util.UUID.randomUUID();
		String u = uuid.toString();
		return u;
	}
}
