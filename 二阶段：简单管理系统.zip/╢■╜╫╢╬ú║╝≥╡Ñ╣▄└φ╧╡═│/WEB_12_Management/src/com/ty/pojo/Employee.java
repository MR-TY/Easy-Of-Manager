package com.ty.pojo;
import java.io.Serializable;
import java.util.Date;
/**
 * Ա��ʵ����
* @ClassName: Employee  
* @Description: TODO(������һ�仰��������������)  
* @author Administrator  
* @date 2017��12��31��  
*
 */
public class Employee implements Serializable{
	  private Integer eId;		//Ա����id
	  private String eName;		//�û�������
	  private Integer eGender;	//Ա�����Ա�
	  private String eTelNum;	//Ա���ĵ绰����
	  private String eEmail;	//Ա��������
	  private Integer  jId;		//ְλ��id	
	  private String eStu;		//Ա����ѧ��
	  private Integer dId;		//���ŵ�id
	  private String eIdCard;	//Ա��������֤
	  private Date eCreateTime;	//Ա���Ĵ���ʱ��
	  private String eAddress;	//Ա���ĵ�ַ
	  private Job job;          //Ա����ְλ
	  private Dept dept;        //Ա���Ĳ���
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(Integer eId, String eName, Integer eGender, String eTelNum, String eEmail, Integer jId, String eStu,
			Integer dId, String eIdCard, Date eCreateTime, String eAddress, Job job, Dept dept) {
		super();
		this.eId = eId;
		this.eName = eName;
		this.eGender = eGender;
		this.eTelNum = eTelNum;
		this.eEmail = eEmail;
		this.jId = jId;
		this.eStu = eStu;
		this.dId = dId;
		this.eIdCard = eIdCard;
		this.eCreateTime = eCreateTime;
		this.eAddress = eAddress;
		this.job = job;
		this.dept = dept;
	}
	public Integer geteId() {
		return eId;
	}
	public void seteId(Integer eId) {
		this.eId = eId;
	}
	public String geteName() {
		return eName;
	}
	public void seteName(String eName) {
		this.eName = eName;
	}
	public Integer geteGender() {
		return eGender;
	}
	public void seteGender(Integer eGender) {
		this.eGender = eGender;
	}
	public String geteTelNum() {
		return eTelNum;
	}
	public void seteTelNum(String eTelNum) {
		this.eTelNum = eTelNum;
	}
	public String geteEmail() {
		return eEmail;
	}
	public void seteEmail(String eEmail) {
		this.eEmail = eEmail;
	}
	public Integer getjId() {
		return jId;
	}
	public void setjId(Integer jId) {
		this.jId = jId;
	}
	public String geteStu() {
		return eStu;
	}
	public void seteStu(String eStu) {
		this.eStu = eStu;
	}
	public Integer getdId() {
		return dId;
	}
	public void setdId(Integer dId) {
		this.dId = dId;
	}
	public String geteIdCard() {
		return eIdCard;
	}
	public void seteIdCard(String eIdCard) {
		this.eIdCard = eIdCard;
	}
	public Date geteCreateTime() {
		return eCreateTime;
	}
	public void seteCreateTime(Date eCreateTime) {
		this.eCreateTime = eCreateTime;
	}
	public String geteAddress() {
		return eAddress;
	}
	public void seteAddress(String eAddress) {
		this.eAddress = eAddress;
	}
	public Job getJob() {
		return job;
	}
	public void setJob(Job job) {
		this.job = job;
	}
	public Dept getDept() {
		return dept;
	}
	public void setDept(Dept dept) {
		this.dept = dept;
	}
	@Override
	public String toString() {
		return "Employee [eId=" + eId + ", eName=" + eName + ", eGender=" + eGender + ", eTelNum=" + eTelNum
				+ ", eEmail=" + eEmail + ", jId=" + jId + ", eStu=" + eStu + ", dId=" + dId + ", eIdCard=" + eIdCard
				+ ", eCreateTime=" + eCreateTime + ", eAddress=" + eAddress + ", job=" + job + ", dept=" + dept + "]";
	}
	
}