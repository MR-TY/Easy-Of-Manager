package com.ty.pojo;
import java.io.Serializable;
import java.util.Date;
/**
 * ����ʵ����
* @ClassName: Download  
* @Description: TODO(������һ�仰��������������)  
* @author Administrator  
* @date 2017��12��31��  
*
 */
public class Download implements Serializable{
	 private Integer doId;			//���ص�id
	 private String doDes;			//���ص�����
	 private String doTitle;		//���ص�����
	 private Date doCreateTime;	//�������Ĵ�����ʵ��
	 private String filePath;		//���صĵ�ַ
	 private Integer uId;			//�û���Id
	 private User user;
	public Download() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Download(Integer doId, String doDes, String doTitle, Date doCreateTime, String filePath, Integer uId,
			User user) {
		super();
		this.doId = doId;
		this.doDes = doDes;
		this.doTitle = doTitle;
		this.doCreateTime = doCreateTime;
		this.filePath = filePath;
		this.uId = uId;
		this.user = user;
	}
	public Integer getDoId() {
		return doId;
	}
	public void setDoId(Integer doId) {
		this.doId = doId;
	}
	public String getDoDes() {
		return doDes;
	}
	public void setDoDes(String doDes) {
		this.doDes = doDes;
	}
	public String getDoTitle() {
		return doTitle;
	}
	public void setDoTitle(String doTitle) {
		this.doTitle = doTitle;
	}
	public Date getDoCreateTime() {
		return doCreateTime;
	}
	public void setDoCreateTime(Date doCreateTime) {
		this.doCreateTime = doCreateTime;
	}
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	public Integer getuId() {
		return uId;
	}
	public void setuId(Integer uId) {
		this.uId = uId;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	@Override
	public String toString() {
		return "Download [doId=" + doId + ", doDes=" + doDes + ", doTitle=" + doTitle + ", doCreateTime=" + doCreateTime
				+ ", filePath=" + filePath + ", uId=" + uId + ", user=" + user + "]";
	}
}
