package com.ty.controll;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ty.pojo.Notice;
import com.ty.pojo.User;
import com.ty.serviceimp.NoticeService;
import com.ty.serviceimp.UserService;
import com.ty.utils.DbUtils;
import com.ty.utils.ObjectParam;
import com.ty.utils.ObjectUtils;
	/**
	 * ��ȡ�������
	 * @author Administrator
	 *
	 */
	public class NoticeControll extends HttpServlet{
		NoticeService noticeService = null;
		UserService userService = null;
	public NoticeControll() throws Exception {
		noticeService = (NoticeService) ObjectUtils.getObject("noticeService");
		userService = (UserService) ObjectUtils.getObject("userService");
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String methodName = req.getParameter("method");
		Notice notice = null;
		try {
			 notice = ObjectParam.getObject(req, Notice.class);
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			jugement(methodName,notice,req,resp);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * �ж�ʹ��ʲô����
	 * @param methodName
	 * @param notice
	 * @param req
	 * @param resp
	 * @throws Exception 
	 */
	private void jugement(String methodName, Notice notice, HttpServletRequest req, HttpServletResponse resp) throws Exception {
		if ("findAllNotice".equals(methodName)) {
			findAllNotice(req,resp);
		}else if ("deleteOneNotice".equals(methodName)) {
			deleteOneNotice(notice,req,resp);
		}else if ("insertOneNotice".equals(methodName)) {
			insertOneNotice(notice,req,resp);
		}else if ("insertNoticeJSP".equals(methodName)) {
			jump("/WEB-INF/jsp/notice/showAddNotice.jsp",req,resp);
		}else if ("findOneNotice".equals(methodName)) {
			findOneNotice(notice,req,resp);
		}else if ("findNotceLikeByNameAndContent".equals(methodName)) {
			findNotceLikeByNameAndContent(notice,req,resp);
		}else if ("findOneNoticeAndJumpshowUpdateNotice".equals(methodName)) {
			findOneNoticeAndJumpshowUpdateNotice(notice,req,resp);
		}else if ("updateOneNotice".equals(methodName)) {
			updateOneNotice(notice,req,resp);
		}
	}
	/**
	 * ͨ��id�޸�һ�����ţ��޸�֮��ͨ��session��ȡ�޸��˵����֣��������޸�
	 * @param notice
	 * @param req
	 * @param resp
	 */
	private void updateOneNotice(Notice notice, HttpServletRequest req, HttpServletResponse resp) {
		try {
			notice.setnCreateTime(new Date());
			System.out.println(notice);
			getUser(notice, req);//��ȡ��¼�û��Ķ���
			noticeService.updateNoticeById(notice);
			System.out.println("�޸�֮��----"+notice);
			jump("/notices?method=findAllNotice",req,resp);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * ����һ�����沢��ת�����µ�ҳ��
	 * @param notice
	 * @param req
	 * @param resp
	 */
	private void findOneNoticeAndJumpshowUpdateNotice(Notice notice, HttpServletRequest req, HttpServletResponse resp) {
		try {
			Notice notice2 = noticeService.findNoticeById(notice);
			req.setAttribute("notice", notice2);
			jump("/WEB-INF/jsp/notice/showUpdateNotice.jsp",req,resp);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * ͨ�����ֺ����ݽ���ģ������
	 * @param notice
	 * @param req
	 * @param resp
	 */
	private void findNotceLikeByNameAndContent(Notice notice, HttpServletRequest req, HttpServletResponse resp) {
		try {
			System.out.println("--------����ģ�����ҵ�ҳ��--------");
			List<Notice> notices = noticeService.findNoticeByNameAndContentLike(notice);
			notices = wrapperNotice(notices);
			System.out.println(notices);
			req.setAttribute("notices", notices);
			jump("/WEB-INF/jsp/notice/notice.jsp",req,resp);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * ͨ��id��ѯһ������,���ҶԹ������Ԥ���Ĺ���
	 * @param notice
	 * @param req
	 * @param resp
	 */
	private void findOneNotice(Notice notice, HttpServletRequest req, HttpServletResponse resp) {
		try {
			Notice notice2 = noticeService.findNoticeById(notice);
			req.setAttribute("notice", notice2);
			jump("/WEB-INF/jsp/notice/previewNotice.jsp",req,resp);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * ����һ������
	 * @param notice
	 * @param req
	 * @param resp
	 */
	private void insertOneNotice(Notice notice, HttpServletRequest req, HttpServletResponse resp) {
		try {
			notice.setnCreateTime(new Date());//����ʱ��
			System.out.println(notice);
			getUser(notice, req);//��ȡ��¼�û��Ķ���
			noticeService.insert(notice);
			System.out.println(notice);
			jump("/notices?method=findAllNotice",req,resp);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * ��õ�¼�û��Ķ���
	 * @param notice
	 * @param req
	 */
	private void getUser(Notice notice, HttpServletRequest req) {
		User user = (User) req.getSession().getAttribute("user");
		int uId = user.getuId();
		notice.setuId(uId);
	}
	/**
	 * ����idɾ��һ������
	 * @param notice
	 * @param req
	 * @param resp
	 */
	private void deleteOneNotice(Notice notice, HttpServletRequest req, HttpServletResponse resp) {
		System.out.println("-----����ɾ����ҳ��-------");
		try {
			noticeService.deleteNoticeById(notice);
			jump("/notices?method=findAllNotice",req,resp);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * �������еĹ���
	 * @param req
	 * @param resp
	 * @throws Exception 
	 */
	private void findAllNotice(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		List<Notice> notices = noticeService.findAllNotice();
		notices = wrapperNotice(notices);
		System.out.println(notices);
		req.setAttribute("notices", notices);
		jump("/WEB-INF/jsp/notice/notice.jsp",req,resp);
	}
	
	/**
	 * �Թ���Ĳ�ѯ�����ٴεķ�װ
	 * @param notices
	 * @return
	 * @throws Exception 
	 */
	private List<Notice> wrapperNotice(List<Notice> notices) throws Exception {
		List<Notice> returnNotice = new ArrayList<>();
		for (Notice notice:notices) {
			Integer uId = notice.getuId();
			String Name = userService.findNameById(uId);
			notice.setUser(new User(null, Name, null, null, null, null));
			returnNotice.add(notice);
		}
		return returnNotice;
	}
	/**
	 * ��תҳ��
	 * @param string
	 * @param req
	 * @param resp
	 * @throws Exception 
	 * @throws ServletException 
	 */
	private void jump(String path, HttpServletRequest req, HttpServletResponse resp) throws ServletException, Exception {
		req.getRequestDispatcher(path).forward(req, resp);
	}
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}
}
