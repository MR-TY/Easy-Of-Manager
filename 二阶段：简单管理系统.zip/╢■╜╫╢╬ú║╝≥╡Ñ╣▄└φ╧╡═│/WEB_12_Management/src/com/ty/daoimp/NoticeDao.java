package com.ty.daoimp;
import java.util.List;

import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.ty.dao.INoticeDao;
import com.ty.pojo.Employee;
import com.ty.pojo.Notice;
import com.ty.pojo.User;
import com.ty.utils.DbUtils;
public class NoticeDao implements INoticeDao{
	@Override
	public void insert(Notice notice) throws Exception {
		String sql = "insert into t_notice(nName, nContent,nCreateTime ,uId) values(?,?,?,?)";
		DbUtils.getQueryRunner().update(sql, notice.getnName(),notice.getnContent(),notice.getnCreateTime(),notice.getuId());
	}

	@Override
	public void deleteNoticeById(Notice notice) throws Exception {
		String sql = "delete from t_notice where nId = ?";
		DbUtils.getQueryRunner().update(sql,notice.getnId());
	}

	@Override
	public void updateNoticeById(Notice notice) throws Exception {
		String sql = "update t_notice set nName=?,nContent=?,nCreateTime=?,uId=? where nId=?";
		DbUtils.getQueryRunner().update(sql,
				notice.getnName(),
				notice.getnContent(),
				notice.getnCreateTime(),
				notice.getuId(),
				notice.getnId()
			);
	}

	@Override
	public List<Notice> findAllNotice() throws Exception {
		String sql = "select * from t_notice";
		return DbUtils.getQueryRunner().query(sql, new BeanListHandler<Notice>(Notice.class));
	}

	@Override
	public Notice findNoticeById(Notice notice) throws Exception {
		String sql = "select * from t_notice where nId=?";
		return DbUtils.getQueryRunner().query(sql, new BeanHandler<Notice>(Notice.class),notice.getnId());
	}

	@Override
	public List<Notice> findNoticeByNameAndContentLike(Notice notice) throws Exception {
		StringBuilder sql = new StringBuilder("select * from t_notice where 1=1");
		if (notice.getnName()!=null&&!notice.getnName().equals("")) {
			sql.append(" and nName like ?");
		}
		if (notice.getnContent()!=null&&!notice.getnContent().equals("")) {
			sql.append(" and nContent like ?");
		}
		return DbUtils.getQueryRunner().query(sql.toString(), new BeanListHandler<Notice>(Notice.class),"%"+notice.getnName()+"%","%"+notice.getnContent()+"%");
	}

	@Override
	public void updateNoticeUId(Notice notice) throws Exception {
		String sql = "update t_notice set uId=? where nId=?";
		DbUtils.getQueryRunner().update(sql, notice.getuId(),notice.getnId());		
	}
}
