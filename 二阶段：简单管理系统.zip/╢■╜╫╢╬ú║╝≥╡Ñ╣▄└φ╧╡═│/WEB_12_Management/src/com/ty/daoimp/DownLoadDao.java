package com.ty.daoimp;
import java.util.List;

import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import com.ty.dao.IDownLoadDao;
import com.ty.pojo.Dept;
import com.ty.pojo.Download;
import com.ty.pojo.Job;
import com.ty.utils.DbUtils;

public class DownLoadDao implements IDownLoadDao{

	@Override
	public void insert(Download download) throws Exception {
		String sql = "insert into t_download(doDes, doTitle,doCreateTime,uId,filePath) values(?,?,?,?,?)";
		DbUtils.getQueryRunner().update(sql,
					download.getDoDes(),
					download.getDoTitle(),
					download.getDoCreateTime(),
					download.getuId(),
					download.getFilePath()
				);
	}

	@Override
	public void deleteDownloadById(Download download) throws Exception {
		String sql = "delete from t_download where doId = ?";
		DbUtils.getQueryRunner().update(sql,
					download.getDoId()
				);
	}

	@Override
	public void updateDownloadById(Download download) throws Exception {
		String sql = "update t_download set doDes=?,doTitle=?,doCreateTime=?,uId=?,filePath=? where doId=?";
		DbUtils.getQueryRunner().update(sql,
				download.getDoDes(),
				download.getDoTitle(),
				download.getDoCreateTime(),
				download.getuId(),
				download.getFilePath(),
				download.getDoId()
			);
	}

	@Override
	public List<Download> findDownloadByTitileName(Download download) throws Exception {
		String sql = "select * from t_download where doTitle like ?";
		return DbUtils.getQueryRunner().query(sql, new BeanListHandler<Download>(Download.class),"%"+download.getDoTitle()+"%");
	}

	@Override
	public List<Download> findAllDownload() throws Exception {
		String sql = "select * from t_download";
		return DbUtils.getQueryRunner().query(sql, new BeanListHandler<Download>(Download.class));
	}

	@Override
	public Download findOneFile(Download download) throws Exception {
		String sql = "select * from t_download where doId = ?";
		return DbUtils.getQueryRunner().query(sql, new BeanHandler<Download>(Download.class),download.getDoId());
	}

}
