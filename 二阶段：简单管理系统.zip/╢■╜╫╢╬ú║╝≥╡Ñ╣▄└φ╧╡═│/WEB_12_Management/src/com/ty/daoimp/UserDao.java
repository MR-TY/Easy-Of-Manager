package com.ty.daoimp;
import java.util.List;

import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.ty.Wrap.MyStringResultHandle;
import com.ty.dao.IUserDao;
import com.ty.pojo.Employee;
import com.ty.pojo.Notice;
import com.ty.pojo.User;
import com.ty.utils.DbUtils;
public class UserDao implements IUserDao{

	@Override
	public void insert(User user) throws Exception {
		String sql = "insert into t_user(uName, uPwd,uLoginName,uCreateTime,uState) values(?,?,?,?,?)";
		DbUtils.getQueryRunner().update(sql,
				user.getuName(),
				user.getuPwd(),
				user.getuLoginName(),
				user.getuCreateTime(),
				user.getuState()
			);
	}

	@Override
	public void deleteUserById(User user) throws Exception {
		String sql = "delete from t_user where uId = ?";
		DbUtils.getQueryRunner().update(sql,user.getuId());
	}

	@Override
	public void updateUserById(User user) throws Exception {
		String sql = "update t_user set uName=?,uPwd=?,uLoginName=?,uCreateTime=?,uState=? where uId=?";
		DbUtils.getQueryRunner().update(sql,
				user.getuName(),
				user.getuPwd(),
				user.getuLoginName(),
				user.getuCreateTime(),
				user.getuState(),
				user.getuId()
			);
	}

	@Override
	public List<User> findUserByUserNameAndStateLike(User user) throws Exception {
		StringBuilder sql = new StringBuilder("select * from t_user where 1=1");
		if (user.getuName()!=null&&!user.getuName().equals("")){
			sql.append(" and uName= '"+user.getuName()+"'");
		}
		if (user.getuState()!=null) {
			sql.append(" and uState= "+user.getuState());
		}
		return DbUtils.getQueryRunner().query(sql.toString(), new BeanListHandler<User>(User.class));
	}

	@Override
	public List<User> findAll() throws Exception {
		System.out.println("---------------����");
		return 	DbUtils.getQueryRunner().query("select * from t_user", new BeanListHandler<User>(User.class));
	}

	@Override
	public User findUserByUserNameAndPwd(User user) throws Exception {
		String sql = "select * from t_user where uLoginName=? and uPwd=?";
		return DbUtils.getQueryRunner().query(sql, new BeanHandler<User>(User.class),user.getuLoginName(),user.getuPwd());	
	}

	@Override
	public User queryOneUser(User user) throws Exception {
		String sql = "select * from t_user where uId=?";
		return DbUtils.getQueryRunner().query(sql, new BeanHandler<User>(User.class),user.getuId());
	}

	@Override
	public String findNameById(Integer uId) throws Exception {
		String sql = "select uName from t_user where uId=?";
		User user = DbUtils.getQueryRunner().query(sql,  new BeanHandler<User>(User.class),uId);
		if (user == null) {
			return null;
		}
		return user.getuName();
	}

	@Override
	public List<Notice> findNoticesByUserId(User user) throws Exception {
		String sql = "SELECT * FROM  t_notice  WHERE uId=?";
		return DbUtils.getQueryRunner().query(sql, new BeanListHandler<Notice>(Notice.class),user.getuId());
	}
}
