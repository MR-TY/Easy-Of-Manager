package com.ty.daoimp;

import java.util.List;

import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.ty.dao.IEmpoyDao;
import com.ty.pojo.Dept;
import com.ty.pojo.Employee;
import com.ty.pojo.Job;
import com.ty.utils.DbUtils;

public class EmpoyDao implements IEmpoyDao{
	@Override
	public void insert(Employee employee) throws Exception {
		String sql = "insert into t_emp(eName, eGender,eTelNum,eEmail, jId, eStu, dId,eIdCard,eCreateTime,eAddress) values(?,?,?,?,?,?,?,?,?,?)";
		DbUtils.getQueryRunner().update(sql, 
				employee.geteName(),
				employee.geteGender(),
				employee.geteTelNum(),
				employee.geteEmail(),
				employee.getjId(),
				employee.geteStu(),
				employee.getdId(),
				employee.geteIdCard(),
				employee.geteCreateTime(),
				employee.geteAddress()
			);
	}

	@Override
	public void deleteEmployById(Employee employee) throws Exception {
		String sql = "delete from t_emp where eId = ?";
		DbUtils.getQueryRunner().update(sql,employee.geteId());
	}

	@Override
	public void updateEmployById(Employee employee) throws Exception {
		String sql = "update t_emp set eName=?,eGender=?,eTelNum=?,eEmail=?,jId=?,eStu=?,dId=?,eIdCard=?,eCreateTime=?,eAddress=?  where eId=?";
		DbUtils.getQueryRunner().update(sql,
				employee.geteName(),
				employee.geteGender(),
				employee.geteTelNum(),
				employee.geteEmail(),
				employee.getjId(),
				employee.geteStu(),
				employee.getdId(),
				employee.geteIdCard(),
				employee.geteCreateTime(),
				employee.geteAddress(),
				employee.geteId()
			);
	}

	@Override
	public List<Employee> findEmployByCompositionCondition(Employee employee) throws Exception {
		StringBuilder sql = new StringBuilder("select * from t_emp where 1=1");
		if (employee.getjId()!=null) {
			sql.append(" and jId like ?");
		}
		if (employee.geteName()!=null&&!employee.geteName().equals("")) {
			sql.append(" and eName like ?");
		}
		if(employee.geteIdCard()!=null&&!employee.geteIdCard().equals("")){
			sql.append(" and eIdCard like ?");
		}
		if (employee.geteGender()!=null) {
			sql.append(" and eGender like ?");
		}
		if (employee.geteTelNum()!=null&&!employee.geteTelNum().equals("")) {
			sql.append(" and eTelNum like ?");
		}
		if (employee.getdId()!=null) {
			sql.append(" and dId like ?");
		}
		return DbUtils.getQueryRunner().query(sql.toString(), new BeanListHandler<Employee>(Employee.class),"%"+employee.getjId()+"%","%"+employee.geteName()+"%","%"+employee.geteIdCard()+"%","%"+employee.geteGender()+"%","%"+employee.geteTelNum()+"%","%"+employee.getdId()+"%");
	}

	@Override
	public List<Employee> findAll() throws Exception {
		String sql = "select * from t_emp";
		return DbUtils.getQueryRunner().query(sql, new BeanListHandler<Employee>(Employee.class));
	}

	@Override
	public Employee findOneEmp(Employee employee) throws Exception {
		String sql = "select * from t_emp where eId=?";
		return DbUtils.getQueryRunner().query(sql, new BeanHandler<Employee>(Employee.class),employee.geteId());
	}

	@Override
	public void updateEmpId(Employee employee) throws Exception {
		String sql = "update t_emp set dId=? where eId=?";
		DbUtils.getQueryRunner().update(sql, employee.getdId(),employee.geteId());
	}

	@Override
	public void updateEmpJId(Employee employee) throws Exception {
		String sql = "update t_emp set jId=? where eId=?";
		DbUtils.getQueryRunner().update(sql, employee.getjId(),employee.geteId());		
	}
}
