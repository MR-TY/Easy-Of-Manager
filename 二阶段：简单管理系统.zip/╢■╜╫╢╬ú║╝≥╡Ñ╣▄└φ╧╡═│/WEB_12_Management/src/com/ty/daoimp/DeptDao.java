package com.ty.daoimp;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.ty.Wrap.MyStringResultHandle;
import com.ty.dao.IDeptDao;
import com.ty.pojo.Dept;
import com.ty.pojo.Employee;
import com.ty.pojo.Job;
import com.ty.pojo.User;
import com.ty.utils.DbUtils;

public class DeptDao implements IDeptDao{

	@Override
	public void insert(Dept dept) throws Exception {
		String sql = "insert into t_dept(dName, dDes) values(?,?)";
		DbUtils.getQueryRunner().update(sql,dept.getdName(),dept.getdDes());
	}

	@Override
	public void deleteDeptById(Dept dept) throws Exception {
		String sql = "delete from t_dept where dId = ?";
		DbUtils.getQueryRunner().update(sql,dept.getdId());
	}

	@Override
	public void updateDeptById(Dept dept) throws Exception {
		String sql = "update t_dept set dName=?,dDes=? where dId=?";
		DbUtils.getQueryRunner().update(sql,
					dept.getdName(),
					dept.getdDes(),
					dept.getdId()
				);
	}

	@Override
	public List<Dept> findDeptByDeptNameLike(Dept dept) throws Exception {
		String sql = "select * from t_dept where dName like ?";
		/*
		 * "%"+dept.getdName()+"%"����д��:  ==="%'"+dept.getdName()+"'%"=====
		 */
		return DbUtils.getQueryRunner().query(sql, new BeanListHandler<Dept>(Dept.class),"%"+dept.getdName()+"%");
	}

	@Override
	public List<Dept> findDeptAll() throws Exception {
		String sql = "select * from t_dept";
		return DbUtils.getQueryRunner().query(sql, new BeanListHandler<Dept>(Dept.class));
	}

	@Override
	public Dept findOneDept(Dept dept) throws Exception{
		String sql = "select * from t_dept where dId=?";
		return DbUtils.getQueryRunner().query(sql, new BeanHandler<Dept>(Dept.class),dept.getdId());
		
	}

	@Override
	public String findNameById(Integer dId) throws Exception {
		System.out.println("������sql��");
			String sql = "select dName from t_dept where dId=?";
			Dept dept =  DbUtils.getQueryRunner().query(sql, new BeanHandler<Dept>(Dept.class),dId);
			if (dept==null) {
				System.out.println("����Ϊnull");
				return null;
			}
			System.out.println(dept.getdName());
			return dept.getdName();
	}

	@Override
	public List<Employee> findEmpByDeptId(Dept dept) throws Exception {
		
		String sql = "SELECT * FROM  t_emp  WHERE dId=?";
		return DbUtils.getQueryRunner().query(sql, new BeanListHandler<Employee>(Employee.class),dept.getdId());
	}
}
