package com.ty.daoimp;
import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.ty.Wrap.MyStringResultHandle;
import com.ty.dao.IJobDao;
import com.ty.pojo.Dept;
import com.ty.pojo.Employee;
import com.ty.pojo.Job;
import com.ty.pojo.Notice;
import com.ty.utils.DbUtils;
public class JobDao implements IJobDao{

	@Override
	public void insert(Job job) throws Exception {
		String sql = "insert into t_job(jName,jDes) values(?,?)";
		DbUtils.getQueryRunner().update(sql,job.getjName(),job.getjDes());
	}

	@Override
	public void deleteJobById(Job job) throws Exception {
		String sql = "delete from t_job where jId = ?";
		DbUtils.getQueryRunner().update(sql,job.getjId());
	}

	@Override
	public void updateJobById(Job job) throws Exception {
		String sql = "update t_job set jName=?,jDes=? where jId=?";
		DbUtils.getQueryRunner().update(sql,job.getjName(),job.getjDes(),job.getjId());
	}

	@Override
	public List<Job> findJobByNameLike(Job job) throws Exception {
		String sql = "select * from t_job where jName like ?";
		return DbUtils.getQueryRunner().query(sql, new BeanListHandler<Job>(Job.class),"%"+job.getjName()+"%");
	}

	@Override
	public List<Job> findJobAll() throws Exception {
		String sql = "select * from t_job";
		return DbUtils.getQueryRunner().query(sql, new BeanListHandler<Job>(Job.class));
	}

	@Override
	public Job findOneJob(Job job) throws Exception {
		String sql = "select * from t_job where jId=?";
		return DbUtils.getQueryRunner().query(sql, new BeanHandler<Job>(Job.class),job.getjId());
	}

	@Override
	public String findNameById(Integer jId) throws Exception{
		String sql = "select jName from t_job where jId=?";
		Job job = DbUtils.getQueryRunner().query(sql,new BeanHandler<Job>(Job.class),jId);
		if (job==null) {
			return null;
		}
		return job.getjName();
	}

	@Override
	public List<Employee> findEmpByJobId(Job job) throws Exception {
		String sql = "SELECT * FROM  t_emp  WHERE jId=?";
		return DbUtils.getQueryRunner().query(sql, new BeanListHandler<Employee>(Employee.class),job.getjId());
	}
}
