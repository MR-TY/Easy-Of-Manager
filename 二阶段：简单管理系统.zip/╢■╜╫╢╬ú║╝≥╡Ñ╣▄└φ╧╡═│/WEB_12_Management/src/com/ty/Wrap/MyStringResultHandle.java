package com.ty.Wrap;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Set;
import org.apache.commons.dbutils.ResultSetHandler;
public class MyStringResultHandle<T> implements ResultSetHandler<T>{

	@Override
	public T handle(ResultSet resultSet) throws SQLException {
		resultSet.next();
		String val = resultSet.getString(1);
		return (T) val;
	}

}
